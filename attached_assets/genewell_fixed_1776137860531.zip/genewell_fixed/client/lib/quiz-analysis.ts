// Client-side quiz analysis - 100% browser-compatible
// Handles ALL quiz question permutations and combinations
// Quiz fields: age, gender, wakeUpTime, mealsPerDay, tiredTime, bloatingFrequency,
//   stressLevel, hungerFrequency, weightGoal, sleepHours, activityLevel, cravings,
//   energyLevels, hydrationHabits, digestiveIssues, medicalConditions, eatingOut,
//   exercisePreference, workSchedule, dnaUpload, skinConcerns, moodPatterns,
//   foodIntolerances, supplementUsage, userName, userEmail, userPhone, userLocation

export interface PersonalizationData {
  profile: {
    name: string;
    email: string;
    age: number;
    gender: string;
    estimatedHeightCm: number;
    estimatedWeightKg: number;
    estimatedBMR: number;
    estimatedTDEE: number;
    proteinGrams: number;
    carbsGrams: number;
    fatsGrams: number;
    stressScore: number;
    sleepScore: number;
    activityScore: number;
    energyScore: number;
    medicalConditions: string[];
    digestiveIssues: string[];
    foodIntolerances: string[];
    skinConcerns: string[];
    dietaryPreference: string;
    exercisePreference: string[];
    workSchedule: string;
    region: string;
    recommendedTests: string[];
    supplementPriority: string[];
    exerciseIntensity: string;
    mealFrequency: number;
    dnaConsent: boolean;
  };
  insights: {
    metabolicInsight: string;
    recommendedMealTimes: string[];
    calorieRange: { min: number; max: number };
    macroRatios: { protein: number; carbs: number; fats: number };
    supplementStack: Array<{ name: string; reason: string; dosage?: string }>;
    workoutStrategy: string;
    sleepStrategy: string;
    stressStrategy: string;
  };
}

// ─────────────────────────────────────────────────────────────
// SCORE MAPS — Every possible quiz answer value mapped to score
// ─────────────────────────────────────────────────────────────

const STRESS_SCORE_MAP: Record<string, number> = {
  "very-high": 85,
  "moderate": 55,
  "low": 30,
  "minimal": 10,
};

const SLEEP_MIDPOINT_MAP: Record<string, number> = {
  "less-than-5": 4,
  "5-6": 5.5,
  "6-7": 6.5,  // not in quiz but handle defensively
  "7-8": 7.5,
  "more-than-8": 8.5,
};

const SLEEP_DISPLAY_MAP: Record<string, string> = {
  "less-than-5": "< 5",
  "5-6": "5–6",
  "6-7": "6–7",
  "7-8": "7–8",
  "more-than-8": "> 8",
};

const ACTIVITY_SCORE_MAP: Record<string, number> = {
  "sedentary": 15,
  "lightly-active": 40,
  "moderately-active": 65,
  "highly-active": 95,
  "very-active": 80, // defensive — not in quiz but possible from old data
};

const ACTIVITY_MULTIPLIER_MAP: Record<string, number> = {
  "sedentary": 1.2,
  "lightly-active": 1.375,
  "moderately-active": 1.55,
  "very-active": 1.725,
  "highly-active": 1.9,
};

const ENERGY_SCORE_MAP: Record<string, number> = {
  "very-low": 15,
  "low": 35,
  "moderate": 60,
  "high": 80,
  "very-high": 95,
};

// Hydration: litres per day
const HYDRATION_MAP: Record<string, number> = {
  "less-than-4-glasses": 0.8,
  "4-6-glasses": 1.25,
  "6-8-glasses": 1.75,
  "more-than-8": 2.25,
};

// Age range → numeric midpoint
const AGE_MIDPOINT_MAP: Record<string, number> = {
  "16-20": 18,
  "21-25": 23,
  "26-30": 28,
  "31-35": 33,
  "36-40": 38,
  "41-45": 43,
  "46-50": 48,
  "51-60": 55,
  "60+": 65,
};

// Meal frequency
const MEAL_FREQ_MAP: Record<string, number> = {
  "1": 1,
  "2": 2,
  "3": 3,
  "4-plus": 4,
  "4": 4,
  "5": 5,
  "6": 6,
};

// ─────────────────────────────────────────────────────────────
// BLOOD TEST RECOMMENDATIONS
// ─────────────────────────────────────────────────────────────

const BLOOD_TEST_RECOMMENDATIONS: Record<string, string[]> = {
  "lose-weight": [
    "Fasting Blood Glucose (FBS) & Random Blood Glucose (RBS)",
    "Lipid Profile: Total Cholesterol, LDL, HDL, Triglycerides",
    "Thyroid Function Tests (TSH, Free T3, Free T4)",
    "Complete Hemogram (CBC)",
    "Liver Function Tests (SGOT, SGPT, ALP)",
    "Vitamin D (25-hydroxyvitamin D)",
  ],
  "gain-weight": [
    "Fasting Blood Glucose (FBS)",
    "Lipid Panel (cholesterol, LDL, HDL, triglycerides)",
    "Liver Function Tests (LFT)",
    "Iron Panel (Serum Iron, Ferritin, TIBC)",
    "Vitamin B12 and Folate levels",
    "Vitamin D (25-hydroxyvitamin D)",
  ],
  "maintain": [
    "Complete Hemogram (CBC)",
    "Fasting Blood Glucose (FBS)",
    "Lipid Panel",
    "Thyroid Function (TSH, Free T4)",
    "Vitamin D (25-hydroxyvitamin D)",
  ],
  "no-goal": [
    "Complete Hemogram (CBC)",
    "Fasting Blood Glucose (FBS)",
    "Lipid Panel",
    "Thyroid Function (TSH, Free T4)",
    "Vitamin D (25-hydroxyvitamin D)",
    "Vitamin B12 and Folate",
  ],
  "general-wellness": [
    "Complete Hemogram (CBC)",
    "Fasting Blood Glucose (FBS)",
    "Lipid Panel",
    "Liver Function Tests (LFT)",
    "Thyroid Function Tests (TSH, Free T4)",
    "Vitamin D (25-hydroxyvitamin D)",
    "Electrolytes (Sodium, Potassium)",
  ],
};

// ─────────────────────────────────────────────────────────────
// SUPPLEMENT STACK BUILDER
// ─────────────────────────────────────────────────────────────

function buildSupplementStack(
  gender: string,
  age: number,
  stressScore: number,
  sleepScore: number,
  digestiveIssues: string[],
  energyScore: number,
  moodPatterns: string[],
  medicalConditions: string[],
  existingSupplements: string // supplementUsage field
): string[] {
  const stack: string[] = [];
  const alreadyTaking = existingSupplements.toLowerCase();

  // Always needed — but skip if already taking
  if (!alreadyTaking.includes("multivitamin")) {
    stack.push("Vitamin D3 (2000-4000 IU daily — supports immunity, mood, bone health)");
  } else {
    // They have multivitamin — recommend checking if D3 is adequate dose
    stack.push("Vitamin D3 — verify your multivitamin has ≥1000 IU; most Indian brands have <400 IU");
  }

  stack.push("Omega-3 EPA+DHA (1-2g daily — anti-inflammatory, brain and cardiovascular health)");

  // Magnesium — sleep and stress
  if (sleepScore < 65 || stressScore > 50) {
    stack.push("Magnesium Bisglycinate (300-400mg before bed — sleep, cortisol reduction)");
  }

  // B12 — diet or sleep related
  if (gender !== "male" || age > 30 || sleepScore < 60) {
    if (!alreadyTaking.includes("multivitamin") && !alreadyTaking.includes("specific-deficiency")) {
      stack.push("Vitamin B12 Methylcobalamin (500mcg sublingual daily — energy, nerve health)");
    }
  }

  // Probiotics — digestive
  if (digestiveIssues.length > 0 && !digestiveIssues.every(d => d === "none")) {
    stack.push("Probiotics 10-50 Billion CFU (gut microbiome, digestion, immunity)");
  }

  // L-Theanine — anxiety/mood
  if (moodPatterns.some(m => /anxiety|mood.swing|irritab/i.test(m)) || stressScore > 65) {
    stack.push("L-Theanine 100-200mg (calm focus, reduces anxiety without drowsiness)");
  }

  // Omega-3 extra note for depression
  if (moodPatterns.some(m => /depress/i.test(m))) {
    stack.push("Omega-3 HIGH DOSE 2-3g EPA+DHA specifically (clinical evidence for mood support)");
  }

  // Ashwagandha — high stress
  if (stressScore > 60) {
    stack.push("Ashwagandha KSM-66 300mg (adaptogen — cortisol -23%, stress and sleep)");
  }

  // Thyroid specific
  if (medicalConditions.some(c => /thyroid/i.test(c))) {
    stack.push("Selenium 200mcg (critical for T4→T3 thyroid hormone conversion)");
    stack.push("Zinc 25mg with food (thyroid function and immune support)");
  }

  // PCOS specific
  if (medicalConditions.some(c => /pcos/i.test(c)) && gender === "female") {
    stack.push("Myo-Inositol 2g + D-Chiro-Inositol 50mg 2x/day (PCOS — insulin, hormones, cycles)");
  }

  // Female iron
  if (gender === "female" && age < 50) {
    stack.push("Iron (Ferrous Bisglycinate 25mg, Days 1-7 of cycle only — menstrual loss)");
  }

  // Protein — if not already supplementing
  if (!alreadyTaking.includes("protein")) {
    // Only suggest if activity is moderate+
  }

  return Array.from(new Set(stack)).slice(0, 8);
}

// ─────────────────────────────────────────────────────────────
// MACRO CALCULATOR
// ─────────────────────────────────────────────────────────────

function calculateMacronutrients(
  tdee: number,
  weightKg: number,
  goal: string,
  medicalConditions: string[]
): { protein: number; carbs: number; fats: number } {
  const hasPCOS = medicalConditions.some(c => /pcos/i.test(c));

  let proteinPct = 0.30;
  let carbPct = 0.45;
  let fatPct = 0.25;

  if (hasPCOS) {
    // PCOS: lower carb, higher fat
    proteinPct = 0.30; carbPct = 0.35; fatPct = 0.35;
  } else if (goal === "lose-weight") {
    proteinPct = 0.30; carbPct = 0.40; fatPct = 0.30;
  } else if (goal === "gain-weight" || goal === "build-muscle") {
    proteinPct = 0.30; carbPct = 0.45; fatPct = 0.25;
  } else if (goal === "maintain" || goal === "no-goal") {
    proteinPct = 0.25; carbPct = 0.50; fatPct = 0.25;
  }

  // Determine goal calorie target first
  const goalCalories = goal === "lose-weight" ? tdee - 450
    : goal === "gain-weight" ? tdee + 325
    : tdee + 100;

  const proteinGrams = Math.round((goalCalories * proteinPct) / 4);
  const carbGrams = Math.round((goalCalories * carbPct) / 4);
  const fatGrams = Math.round((goalCalories * fatPct) / 9);

  return { protein: proteinGrams, carbs: carbGrams, fats: fatGrams };
}

// ─────────────────────────────────────────────────────────────
// BLOOD TEST RECOMMENDATIONS
// ─────────────────────────────────────────────────────────────

function getRecommendedBloodTests(
  goal: string,
  medicalConditions: string[],
  gender: string,
  age: number,
  stressScore: number,
  sleepScore: number,
  bmi: number
): string[] {
  const testsSet = new Set<string>();

  const goalTests = BLOOD_TEST_RECOMMENDATIONS[goal] || BLOOD_TEST_RECOMMENDATIONS["general-wellness"];
  goalTests.forEach(t => testsSet.add(t));

  // Always
  testsSet.add("Vitamin D (25-hydroxyvitamin D)");
  testsSet.add("Thyroid Function (TSH, Free T4)");
  testsSet.add("Complete Hemogram (CBC)");

  if (age > 35 || bmi > 25) {
    testsSet.add("Lipid Panel (cholesterol, LDL, HDL, triglycerides)");
    testsSet.add("HbA1c + Fasting Blood Glucose");
  }

  if (gender === "female") {
    testsSet.add("Iron Panel (Ferritin, Serum Iron, TIBC)");
  }

  if (sleepScore < 60 || stressScore > 60) {
    testsSet.add("Vitamin B12 and Folate levels");
    testsSet.add("Magnesium (blood serum)");
  }

  if (medicalConditions.some(c => /thyroid/i.test(c))) {
    testsSet.add("Thyroid Panel (TSH, Free T3, Free T4, Anti-TPO)");
  }

  if (medicalConditions.some(c => /pcos/i.test(c))) {
    testsSet.add("Hormonal Panel (LH, FSH, Testosterone, Estradiol, AMH)");
    testsSet.add("Fasting Insulin + HbA1c");
  }

  if (medicalConditions.some(c => /diabetes/i.test(c))) {
    testsSet.add("HbA1c + Fasting Blood Glucose + Post-Prandial Glucose");
    testsSet.add("Kidney Function Tests (Creatinine, BUN)");
  }

  if (medicalConditions.some(c => /blood.pressure|hypertension/i.test(c))) {
    testsSet.add("Lipid Profile (complete)");
    testsSet.add("Kidney Function Tests");
    testsSet.add("Electrolytes (Sodium, Potassium)");
  }

  return Array.from(testsSet).slice(0, 12);
}

// ─────────────────────────────────────────────────────────────
// INSIGHTS GENERATOR
// ─────────────────────────────────────────────────────────────

function generateInsights(profile: any, quizData: any): PersonalizationData["insights"] {
  const wakeTime = quizData.wakeUpTime || "6-8";
  let recommendedMealTimes: string[] = [];

  if (wakeTime === "before-6") {
    recommendedMealTimes = ["6:00-7:00 AM", "12:00-1:00 PM", "6:30-7:30 PM"];
  } else if (wakeTime === "8-10") {
    recommendedMealTimes = ["9:00-10:00 AM", "1:30-2:30 PM", "7:30-8:30 PM"];
  } else if (wakeTime === "after-10") {
    recommendedMealTimes = ["11:00 AM-12:00 PM", "3:00-4:00 PM", "8:30-9:30 PM"];
  } else {
    // 6-8 AM default
    recommendedMealTimes = ["8:00-9:00 AM", "1:00-2:00 PM", "7:00-8:00 PM"];
  }

  // Hunger frequency affects snack recommendation
  const hungerFreq = quizData.hungerFrequency || "3-4-hours";
  if (hungerFreq === "1-2-hours" || hungerFreq === "depends") {
    // Fast metabolism or variable — add snack time
    recommendedMealTimes = [
      recommendedMealTimes[0],
      recommendedMealTimes[0].replace(/AM|PM/, '') + " + Mid-morning snack",
      recommendedMealTimes[1],
      recommendedMealTimes[2],
    ].filter(Boolean);
  }

  const activityLevel = quizData.activityLevel || "moderately-active";
  const mgmtScore = Math.max(15, 100 - profile.stressScore);

  const sleepStrategy = `Sleep neurobiology research shows that your current sleep score of ${profile.sleepScore}/100 indicates ${
    profile.sleepScore < 40
      ? "CRITICAL sleep deprivation. This is your single highest-priority issue. Prioritize consistent sleep-wake timing above all else."
      : profile.sleepScore < 60
      ? "significant room for improvement. Consistent wake time + dark, cool room + no screens 60 min before bed = the three non-negotiables."
      : profile.sleepScore < 80
      ? "moderate sleep quality. Focus on consistency — same wake time even weekends. Add magnesium bisglycinate 300mg before bed."
      : "good sleep quality. Maintain consistency. 7-9 hours nightly supports all other health interventions."
  }`;

  const stressStrategy = `Your stress management score is ${mgmtScore}/100 — ${
    mgmtScore < 30
      ? "CRITICAL. Chronic high stress elevates cortisol, blocks fat loss, disrupts sleep and immunity. Start with 5 min box breathing (4-4-4-4) every morning before phone."
      : mgmtScore < 50
      ? "needs daily intervention. Box breathing, 20-min walks, and social connection are your most evidence-backed tools."
      : "well managed. Continue daily stress prevention practices."
  }`;

  return {
    metabolicInsight: `Your estimated BMR is ${profile.estimatedBMR} kcal/day. With your ${activityLevel.replace(/-/g," ")} lifestyle, your TDEE is ~${profile.estimatedTDEE} kcal/day. ${
      quizData.weightGoal === "lose-weight" ? `For fat loss: target ${profile.estimatedTDEE - 450} kcal/day.`
      : quizData.weightGoal === "gain-weight" ? `For lean gain: target ${profile.estimatedTDEE + 325} kcal/day.`
      : `To maintain: eat around ${profile.estimatedTDEE} kcal/day.`
    } Note: height and weight are estimated from population averages — update once you have your measurements for precise numbers.`,

    recommendedMealTimes: recommendedMealTimes.slice(0, 4),

    calorieRange: {
      min: Math.round(profile.estimatedTDEE * 0.85),
      max: Math.round(profile.estimatedTDEE * 1.15),
    },

    macroRatios: {
      protein: Math.round((profile.proteinGrams * 4) / profile.estimatedTDEE * 100),
      carbs: Math.round((profile.carbsGrams * 4) / profile.estimatedTDEE * 100),
      fats: Math.round((profile.fatsGrams * 9) / profile.estimatedTDEE * 100),
    },

    supplementStack: profile.supplementPriority.map((supp: string) => {
      const sepIdx = supp.indexOf(" (");
      const name = sepIdx > 0 ? supp.substring(0, sepIdx) : supp;
      const reason = sepIdx > 0 ? supp.substring(sepIdx + 2, supp.length - 1) : "Supports optimal health";
      return { name, reason };
    }),

    workoutStrategy: `${profile.exerciseIntensity.charAt(0).toUpperCase() + profile.exerciseIntensity.slice(1)} intensity protocol: ${
      profile.exerciseIntensity === "low"
        ? "Start with 20-min walks 3x/week. Build to 30 min. No gym needed in weeks 1-4."
        : profile.exerciseIntensity === "moderate"
        ? "4-5 sessions/week. Combine cardio and strength. Progressive overload every 2 weeks."
        : "5-6 sessions/week with periodization. Vary volume and intensity cycles for max results."
    }`,

    sleepStrategy,
    stressStrategy,
  };
}

// ─────────────────────────────────────────────────────────────
// MAIN ANALYSIS FUNCTION
// ─────────────────────────────────────────────────────────────

export function analyzeQuizData(quizData: any, userName?: string, userEmail?: string): PersonalizationData {
  if (!quizData || typeof quizData !== "object") {
    throw new Error("Invalid quiz data: expected an object");
  }

  // ── 1. AGE ──────────────────────────────────────────────────
  const rawAge = quizData.age;
  let age = 28;
  if (rawAge !== undefined && rawAge !== null) {
    if (typeof rawAge === "number" && rawAge > 0 && rawAge < 120) {
      age = rawAge;
    } else {
      const ageStr = String(rawAge);
      const mapped = AGE_MIDPOINT_MAP[ageStr];
      if (mapped) {
        age = mapped;
      } else {
        const dashMatch = ageStr.match(/(\d+)-(\d+)/);
        if (dashMatch) age = Math.round((parseInt(dashMatch[1]) + parseInt(dashMatch[2])) / 2);
        else {
          const singleMatch = ageStr.match(/(\d+)/);
          if (singleMatch) age = parseInt(singleMatch[1]);
        }
      }
    }
  }

  // ── 2. GENDER ───────────────────────────────────────────────
  const gender = (quizData.gender || "female").toLowerCase();
  const isFemale = gender === "female" || gender === "f";
  const isMale = gender === "male" || gender === "m";

  // ── 3. STRESS SCORE ─────────────────────────────────────────
  const stressLevel = quizData.stressLevel || "moderate";
  const stressScore = STRESS_SCORE_MAP[stressLevel] ?? 55;

  // ── 4. SLEEP ────────────────────────────────────────────────
  const sleepHoursEnum = String(quizData.sleepHours || "7-8");
  const sleepMidpoint = SLEEP_MIDPOINT_MAP[sleepHoursEnum] ?? 6.5;
  const rawSleepScore = Math.min(Math.round((sleepMidpoint / 8) * 100), 100);
  // Shift-work penalty: circadian misalignment caps effective sleep quality
  const isShiftWork = /shift/i.test(quizData.workSchedule || "");
  const sleepScore = isShiftWork ? Math.min(rawSleepScore, 70) : rawSleepScore;

  // ── 5. ACTIVITY ─────────────────────────────────────────────
  const activityLevel = quizData.activityLevel || "lightly-active";
  const activityScore = ACTIVITY_SCORE_MAP[activityLevel] ?? 40;
  const activityMultiplier = ACTIVITY_MULTIPLIER_MAP[activityLevel] ?? 1.375;

  // ── 6. ENERGY ───────────────────────────────────────────────
  const energyLevels = quizData.energyLevels || "moderate";
  const energyScore = ENERGY_SCORE_MAP[energyLevels] ?? 60;

  // ── 7. HEIGHT & WEIGHT (estimated — quiz does not collect these) ──
  // Using population average for India by gender and age
  let estimatedHeightCm = isMale ? 170 : 157;
  let estimatedWeightKg = isMale ? 72 : 60;
  // Age adjustments
  if (age > 40) { estimatedWeightKg += isMale ? 3 : 2; }
  if (age > 50) { estimatedWeightKg += isMale ? 2 : 1; }
  // Activity adjustments (lean athletes vs sedentary)
  if (activityScore > 75) { estimatedWeightKg = Math.round(estimatedWeightKg * 0.95); }
  else if (activityScore < 25) { estimatedWeightKg = Math.round(estimatedWeightKg * 1.08); }

  // ── 8. BMR & TDEE (Mifflin-St Jeor) ────────────────────────
  const bmrGenderFactor = isMale ? 5 : -161;
  const estimatedBMR = Math.round(
    10 * estimatedWeightKg + 6.25 * estimatedHeightCm - 5 * age + bmrGenderFactor
  );
  const estimatedTDEE = Math.round(estimatedBMR * activityMultiplier);
  const estimatedBMI = Math.round((estimatedWeightKg / Math.pow(estimatedHeightCm / 100, 2)) * 10) / 10;

  // ── 9. MEALS PER DAY ────────────────────────────────────────
  const rawMeals = quizData.mealsPerDay ?? quizData.mealFrequency ?? quizData.meals_per_day;
  const mealFrequency = rawMeals !== undefined
    ? (MEAL_FREQ_MAP[String(rawMeals)] ?? Number(rawMeals) ?? 3)
    : 3;

  // ── 10. HYDRATION ───────────────────────────────────────────
  const rawHydration = quizData.hydrationHabits ?? quizData.waterIntake ?? quizData.hydration;
  const waterLiters = rawHydration !== undefined
    ? (HYDRATION_MAP[String(rawHydration)] ?? Number(rawHydration) ?? 1.5)
    : 1.5;

  // ── 11. MEDICAL CONDITIONS ──────────────────────────────────
  // BUG FIX: "prefer-not-to-say" must be treated as "none" (not a real condition)
  const rawMedical = quizData.medicalConditions;
  const medicalConditions: string[] = (() => {
    const arr = Array.isArray(rawMedical)
      ? rawMedical
      : rawMedical ? [String(rawMedical)] : [];
    return arr.filter((c: string) => {
      const lower = c.toLowerCase();
      return lower !== "none" && lower !== "prefer-not-to-say" && lower.length > 0;
    });
  })();

  // FIX: Do NOT silently strip PCOS from male profiles.
  // Silently dropping it means the report gives zero feedback and the user
  // never knows their data was ignored. Instead, pass it through as-is
  // and let the PDF renderer show a data-verification note.
  // Male PCOS-equivalent conditions (rare but real: hyperandrogenism, insulin
  // resistance) deserve clinical follow-up, not silent suppression.
  const filteredMedical = medicalConditions; // No gender-based stripping

  // ── 12. DIGESTIVE ISSUES ────────────────────────────────────
  const rawDigestive = quizData.digestiveIssues;
  const rawDigestiveArr: string[] = Array.isArray(rawDigestive)
    ? rawDigestive
    : rawDigestive ? [String(rawDigestive)] : [];
  const digestiveBase = rawDigestiveArr.filter((c: string) =>
    c !== "none" && c.length > 0
  );
  // BloatingFrequency as additional source
  const bloatingFreq = quizData.bloatingFrequency || "never";
  const digestiveIssues = ["often", "sometimes"].includes(bloatingFreq)
    ? [...digestiveBase, ...(!digestiveBase.includes("bloating") && !digestiveBase.includes("gas") ? ["bloating"] : [])]
    : digestiveBase;

  // ── 13. FOOD INTOLERANCES ───────────────────────────────────
  const rawIntolerances = quizData.foodIntolerances;
  const foodIntolerances: string[] = Array.isArray(rawIntolerances)
    ? rawIntolerances.filter((c: string) => c !== "none" && c.length > 0)
    : rawIntolerances && rawIntolerances !== "none"
    ? [String(rawIntolerances)]
    : [];

  // ── 14. SKIN CONCERNS ───────────────────────────────────────
  const rawSkin = quizData.skinConcerns;
  const skinConcerns: string[] = Array.isArray(rawSkin)
    ? rawSkin.filter((c: string) => c !== "none" && c.length > 0)
    : rawSkin && rawSkin !== "none"
    ? [String(rawSkin)]
    : [];

  // ── 15. CRAVINGS ────────────────────────────────────────────
  // BUG FIX: Previously never forwarded to PDF
  const rawCravings = quizData.cravings;
  const cravings: string[] = Array.isArray(rawCravings)
    ? rawCravings.filter((c: string) => c !== "no-cravings" && c.length > 0)
    : rawCravings && rawCravings !== "no-cravings"
    ? [String(rawCravings)]
    : [];

  // ── 16. MOOD PATTERNS ───────────────────────────────────────
  // BUG FIX: Previously never forwarded; now used for anxiety/depression protocols
  const rawMood = quizData.moodPatterns;
  const moodPatterns: string[] = Array.isArray(rawMood)
    ? rawMood.filter((c: string) => c !== "stable" && c.length > 0)
    : rawMood && rawMood !== "stable"
    ? [String(rawMood)]
    : [];

  // ── 17. EXERCISE PREFERENCE ─────────────────────────────────
  const rawExercise = quizData.exercisePreference;
  const exercisePreference: string[] = Array.isArray(rawExercise)
    ? rawExercise.filter((e: string) => e !== "none")
    : rawExercise && rawExercise !== "none"
    ? [String(rawExercise)]
    : []; // empty = no routine yet (beginner)

  // BUG FIX: exercisePreference "none" → beginner tag
  const isExerciseBeginner = exercisePreference.length === 0
    || (Array.isArray(rawExercise) && rawExercise.includes("none"))
    || rawExercise === "none";

  // ── 18. TIRED TIME ──────────────────────────────────────────
  // BUG FIX: tiredTime never set afternoonCrash
  const tiredTime = quizData.tiredTime || "rarely";
  const afternoonCrash = tiredTime === "afternoon";

  // ── 19. EATING OUT ──────────────────────────────────────────
  // BUG FIX: analyzeQuiz was checking quizData.eatingOutFrequency but quiz sends quizData.eatingOut
  const eatingOutFrequency = quizData.eatingOut ?? quizData.eatingOutFrequency ?? "rarely";

  // ── 20. SUPPLEMENT USAGE ────────────────────────────────────
  const supplementUsage = quizData.supplementUsage || "none";

  // ── 21. WEIGHT GOAL → GOALS ARRAY ───────────────────────────
  const weightGoal = quizData.weightGoal || "no-goal";
  const goalsMap: Record<string, string[]> = {
    "lose-weight":  ["lose-weight"],
    "gain-weight":  ["gain-weight"],
    "maintain":     ["maintain"],
    "no-goal":      ["general-wellness"],
    "general-wellness": ["general-wellness"],
    "build-muscle": ["gain-weight"],
  };
  const goals = Array.isArray(quizData.goals) && quizData.goals.length > 0
    ? quizData.goals
    : goalsMap[weightGoal] ?? ["general-wellness"];

  // ── 22. DIET PREFERENCE ─────────────────────────────────────
  const dietaryPreference = quizData.dietaryPreference || "non-veg";

  // ── 23. WORK SCHEDULE ───────────────────────────────────────
  const workSchedule = quizData.workSchedule || "9-to-5";

  // ── 24. REGION / LOCATION ───────────────────────────────────
  const userLocation = quizData.userLocation || quizData.city || "";
  const city = userLocation || "India";

  // ── 25. DNA CONSENT ─────────────────────────────────────────
  const dnaUpload = quizData.dnaUpload || "dont-have";
  const dnaConsent = dnaUpload === "yes-upload";
  const dnaAvailableNotUploaded = dnaUpload === "have-but-no-upload";

  // ── MACROS ──────────────────────────────────────────────────
  const macros = calculateMacronutrients(estimatedTDEE, estimatedWeightKg, weightGoal, filteredMedical);

  // ── EXERCISE INTENSITY ──────────────────────────────────────
  const exerciseIntensity =
    isExerciseBeginner ? "low"
    : activityScore > 75 ? "high"
    : activityScore > 45 ? "moderate"
    : "low";

  // ── BLOOD TESTS ─────────────────────────────────────────────
  const recommendedTests = getRecommendedBloodTests(
    weightGoal, filteredMedical, gender, age, stressScore, sleepScore, estimatedBMI
  );

  // ── SUPPLEMENT STACK ────────────────────────────────────────
  const supplementPriority = buildSupplementStack(
    gender, age, stressScore, sleepScore, digestiveIssues,
    energyScore, moodPatterns, filteredMedical, supplementUsage
  );

  // ── HUNGER FREQUENCY → affects snack recommendations ───────
  const hungerFrequency = quizData.hungerFrequency || "3-4-hours";
  const highMetabolism = hungerFrequency === "1-2-hours";

  const profile = {
    name: (userName || "User").toString().trim() || "User",
    email: (userEmail || "user@genewell.in").toString(),
    age: Number(age) || 28,
    gender: String(gender),
    estimatedHeightCm: Number(estimatedHeightCm),
    estimatedWeightKg: Number(estimatedWeightKg),
    estimatedBMR: Number(estimatedBMR),
    estimatedTDEE: Number(estimatedTDEE),
    proteinGrams: Number(macros.protein),
    carbsGrams: Number(macros.carbs),
    fatsGrams: Number(macros.fats),
    stressScore: Number(stressScore),
    sleepScore: Number(sleepScore),
    activityScore: Number(activityScore),
    energyScore: Number(energyScore),
    medicalConditions: filteredMedical,
    digestiveIssues,
    foodIntolerances,
    skinConcerns,
    dietaryPreference: String(dietaryPreference),
    exercisePreference: isExerciseBeginner ? ["walking"] : exercisePreference,
    workSchedule: String(workSchedule),
    region: "India",
    city: String(city),
    recommendedTests,
    supplementPriority,
    exerciseIntensity: String(exerciseIntensity),
    mealFrequency: Number(mealFrequency) || 3,
    goals,
    dnaConsent,
    // Extended fields — all needed by PDF generator
    sleepHours: sleepMidpoint,
    sleepHoursEnum: sleepHoursEnum,
    waterLiters,
    cravings,
    moodPatterns,
    afternoonCrash,
    eatingOutFrequency: String(eatingOutFrequency),
    hungerFrequency: String(hungerFrequency),
    highMetabolism,
    activityLevel: String(activityLevel),
    tiredTime: String(tiredTime),
    supplementUsage: String(supplementUsage),
    dnaAvailableNotUploaded,
    heightWeightEstimated: true, // Always true — quiz never collects these
    isExerciseBeginner,
    wakeUpTime: String(quizData.wakeUpTime || "6-8"),
    bloatingFrequency: String(bloatingFreq),
  };

  const insights = generateInsights(profile, quizData);

  // Track
  try {
    fetch("/api/track-visit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ page: "/quiz-analysis", referrer: typeof window !== "undefined" ? window.location.href : "" }),
    }).catch(() => {});
  } catch (e) {}

  return { profile, insights };
}
