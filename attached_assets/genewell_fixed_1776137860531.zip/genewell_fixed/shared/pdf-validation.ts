import type { PDFDataBundle, MealItem, WellnessUserProfile } from "./wellness-types";

export interface ValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
  cleaned: PDFDataBundle;
  adjustments: string[];
}

function cleanText(text: string): string {
  if (!text) return "";
  let cleaned = text.replace(/\$\{.*?\}/g, "");
  const commonPlaceholders = ["[Insert", "TODO", "TBD", "PLACEHOLDER", "NARRATIVE_HERE"];
  commonPlaceholders.forEach(p => {
    const reg = new RegExp(p.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi");
    cleaned = cleaned.replace(reg, "");
  });
  return cleaned.replace(/[\uFFFD]|Â|Ã|Å|Ê/g, "");
}

export function validateAndCorrectBundle(bundle: PDFDataBundle): ValidationResult {
  const adjustments: string[] = [];
  const cleaned = structuredClone(bundle);
  const { profile, narratives, mealPlan, rules } = cleaned;

  // 1. Gender–Condition Mismatch
  const genderLower = (profile.gender || "").toLowerCase();
  if (genderLower === "male") {
    const before = profile.medicalConditions.length;
    profile.medicalConditions = profile.medicalConditions.filter(
      c => !c.toLowerCase().includes("pcos")
    );
    if (profile.medicalConditions.length !== before) {
      adjustments.push("PCOS removed: not applicable for male profiles");
    }
    for (const key in narratives) {
      const k = key as keyof typeof narratives;
      if (typeof narratives[k] === "string") {
        const orig = narratives[k] as string;
        const corr = orig.replace(/pcos|ovarian|menstrual/gi, "metabolic balance");
        if (orig !== corr) {
          (narratives as any)[k] = corr;
          if (!adjustments.includes("Narrative adjusted for gender")) {
            adjustments.push("Narrative adjusted for gender");
          }
        }
      }
    }
  }

  // 2. Strip "prefer-not-to-say" and "none" from medical conditions
  const beforeFilter = profile.medicalConditions.length;
  profile.medicalConditions = profile.medicalConditions.filter(c => {
    const lower = c.toLowerCase();
    return lower !== "none" && lower !== "prefer-not-to-say" && lower.trim() !== "";
  });
  if (profile.medicalConditions.length !== beforeFilter) {
    adjustments.push("Non-medical condition values removed from medicalConditions");
  }

  // 3. Food-Intolerance Meal Plan Filtering
  if (mealPlan?.days) {
    const intolerances = profile.foodIntolerances.map(i => i.toLowerCase());
    let itemsRemoved = false;
    for (const day of mealPlan.days) {
      const mealKeys = ["breakfast", "lunch", "dinner", "midMorningSnack", "eveningSnack"] as const;
      for (const key of mealKeys) {
        const val = (day as any)[key];
        if (Array.isArray(val)) {
          const filtered = (val as MealItem[]).filter(item => {
            const name = item.name.toLowerCase();
            if (
              (intolerances.includes("lactose") || intolerances.includes("dairy")) &&
              /milk|paneer|curd|cheese|yogurt|dahi|whey|butter/i.test(name)
            ) return false;
            if (
              intolerances.includes("gluten") &&
              /wheat|roti|bread|maida|semolina|rava|pasta|chapati|paratha/i.test(name)
            ) return false;
            if (
              (intolerances.includes("seafood") || intolerances.includes("fish")) &&
              /fish|prawn|shrimp|seafood|crab|lobster|tuna|salmon/i.test(name)
            ) return false;
            if (
              (intolerances.includes("nuts") || intolerances.includes("peanuts")) &&
              /peanut|almond|cashew|walnut|pistachio|nut/i.test(name)
            ) return false;
            if (
              intolerances.includes("eggs") &&
              /\begg\b|\beggs\b/i.test(name)
            ) return false;
            return true;
          });
          if (filtered.length !== (val as MealItem[]).length) {
            (day as any)[key] = filtered;
            itemsRemoved = true;
          }
        }
      }

      // 4. Macro Re-balancing
      const targetCals = profile.tdee || 2000;
      const deviation = Math.abs(day.totalCalories - targetCals) / targetCals;
      if (deviation > 0.02) {
        const scale = targetCals / day.totalCalories;
        day.totalCalories = Math.round(targetCals);
        day.totalProtein = Math.round(day.totalProtein * scale);
        day.totalCarbs = Math.round(day.totalCarbs * scale);
        day.totalFats = Math.round(day.totalFats * scale);
        const mealKeys2 = ["breakfast", "lunch", "dinner", "midMorningSnack", "eveningSnack"] as const;
        for (const key of mealKeys2) {
          const val = (day as any)[key];
          if (Array.isArray(val)) {
            (val as MealItem[]).forEach(item => {
              item.calories = Math.round(item.calories * scale);
              item.protein = Math.round(item.protein * scale);
              item.carbs = Math.round(item.carbs * scale);
              item.fats = Math.round(item.fats * scale);
              if (item.portion.includes("g")) {
                const g = parseInt(item.portion);
                if (!isNaN(g)) item.portion = `${Math.round(g * scale)}g`;
              }
            });
          }
        }
        if (!adjustments.includes("Calories scaled to match TDEE target")) {
          adjustments.push("Calories scaled to match TDEE target");
        }
      }
    }
    if (itemsRemoved) adjustments.push("Intolerance-conflicting foods removed from meal plan");
  }

  // 5. Narrative Cleanup
  let narrativeFixed = false;
  for (const key in narratives) {
    const k = key as keyof typeof narratives;
    if (typeof narratives[k] === "string") {
      const orig = narratives[k] as string;
      const cleaned2 = cleanText(orig);
      if (orig !== cleaned2) {
        (narratives as any)[k] = cleaned2;
        narrativeFixed = true;
      }
    }
  }
  if (narrativeFixed) adjustments.push("Narrative placeholders cleaned");

  // 6. Lab Tests Sort + Filter
  if (rules.labTestPriority) {
    const before2 = rules.labTestPriority.length;
    rules.labTestPriority = rules.labTestPriority
      .filter(t => t.priority > 0 && t.reason?.length > 5)
      .sort((a, b) => b.priority - a.priority);
    if (rules.labTestPriority.length !== before2) {
      adjustments.push("Lab test list refined");
    }
  }

  // 7. Supplement Dedup
  if (profile.supplementPriority) {
    const seen = new Set<string>();
    const before3 = profile.supplementPriority.length;
    profile.supplementPriority = profile.supplementPriority.filter(s => {
      const key2 = s.toLowerCase().trim().replace(/\s+/g, "");
      if (seen.has(key2)) return false;
      seen.add(key2);
      return true;
    });
    if (profile.supplementPriority.length !== before3) {
      adjustments.push("Duplicate supplements removed");
    }
  }

  cleaned.adjustments = adjustments;
  return { valid: true, errors: [], warnings: [], cleaned, adjustments };
}

export function validatePDFBundle(bundle: PDFDataBundle): ValidationResult {
  return validateAndCorrectBundle(bundle);
}

// ══════════════════════════════════════════════════════════════
// PRE-GENERATION VALIDATION
// ══════════════════════════════════════════════════════════════

export interface PreGenerationCheck {
  canGenerate: boolean;
  criticalErrors: string[];
  autoCorrections: string[];
  warnings: string[];
}

export function runPreGenerationChecks(bundle: PDFDataBundle): PreGenerationCheck {
  const criticalErrors: string[] = [];
  const autoCorrections: string[] = [];
  const warnings: string[] = [];
  const { profile, rules } = bundle;

  // Required fields
  if (!profile.name?.trim()) criticalErrors.push("Profile name missing — cannot personalize PDF.");
  if (!profile.age || profile.age < 10 || profile.age > 110) {
    criticalErrors.push(`Age ${profile.age} invalid. Must be 10–110.`);
  }
  if (!profile.weightKg || profile.weightKg < 20 || profile.weightKg > 350) {
    criticalErrors.push(`Weight ${profile.weightKg}kg invalid.`);
  }
  if (!profile.heightCm || profile.heightCm < 100 || profile.heightCm > 250) {
    criticalErrors.push(`Height ${profile.heightCm}cm invalid.`);
  }
  if (!profile.gender?.trim()) criticalErrors.push("Gender missing.");

  // Goal vs calorie contradiction check
  const goals = (profile.goals || []).map(g => g.toLowerCase());
  const wantsGain = goals.some(g => /gain|muscle|build/.test(g));
  const wantsLoss = goals.some(g => /los|fat|reduc/.test(g));
  const tdee = profile.tdee || 2000;
  const calGoal = (profile as any).calorieGoal || 0;

  if (wantsGain && calGoal > 0 && calGoal < tdee) {
    warnings.push(`Gain goal but calorie target (${calGoal}) < TDEE (${tdee}). PDF auto-corrects to surplus.`);
    autoCorrections.push("Calorie surplus applied for gain goal");
  }
  if (wantsLoss && calGoal > 0 && calGoal > tdee) {
    warnings.push(`Loss goal but calorie target (${calGoal}) > TDEE (${tdee}). PDF auto-corrects to deficit.`);
    autoCorrections.push("Calorie deficit applied for loss goal");
  }

  // Sleep critical flag
  const sleepHrs = profile.sleepHours ?? 0;
  if (sleepHrs > 0 && sleepHrs <= 5) {
    warnings.push(`Critical sleep: ${sleepHrs} hrs detected. Sleep correction prioritized as Action #1.`);
  }

  // Thyroid note
  if ((profile.medicalConditions || []).some(c => /thyroid/i.test(c))) {
    warnings.push("Thyroid detected: TSH lab test marked CRITICAL, ashwagandha warning added.");
  }

  // PCOS on male
  if (
    (profile.gender || "").toLowerCase() === "male" &&
    (profile.medicalConditions || []).some(c => /pcos/i.test(c))
  ) {
    autoCorrections.push("PCOS stripped from male profile");
  }

  // Meal frequency vs calorie feasibility
  const mealFreq = profile.mealFrequency || 3;
  if (mealFreq <= 1 && tdee > 1800) {
    warnings.push(`1 meal/day with ${tdee} kcal target. PDF adds snack options to bridge gap.`);
  }

  // Food intolerance auto-corrections
  const intolerances = (profile.foodIntolerances || []).map(f => f.toLowerCase());
  if (intolerances.some(f => f.includes("lactose") || f.includes("dairy"))) {
    autoCorrections.push("Lactose: all dairy removed from meal plan globally");
  }
  if (intolerances.some(f => f.includes("gluten"))) {
    autoCorrections.push("Gluten: all wheat/roti/bread replaced globally in meal plan");
  }
  if (intolerances.some(f => f.includes("eggs"))) {
    autoCorrections.push("Eggs: egg-free substitutions applied in meal plan");
  }
  if (intolerances.some(f => f.includes("seafood") || f.includes("fish"))) {
    autoCorrections.push("Seafood: fish removed; algae-based DHA supplement recommended");
  }

  // Active modules minimum
  const modules = rules?.activeModules || [];
  if (modules.length < 3) {
    warnings.push(`Only ${modules.length} active modules. PDF may be sparse.`);
  }

  return { canGenerate: criticalErrors.length === 0, criticalErrors, autoCorrections, warnings };
}

/**
 * Validate gender–addon compatibility before purchase.
 */
export function validateAddonGenderCompatibility(
  addonIds: string[],
  gender: string | null | undefined
): { valid: boolean; rejectedAddonIds: string[]; message: string } {
  if (!gender) return { valid: true, rejectedAddonIds: [], message: "" };
  const g = gender.toLowerCase().trim();
  const FEMALE_ONLY = ["addon_women_hormone", "addon_women_hormonal"];
  const MALE_ONLY = ["addon_men_fitness"];
  const rejected: string[] = [];
  if (g === "male") rejected.push(...addonIds.filter(id => FEMALE_ONLY.includes(id)));
  if (g === "female") rejected.push(...addonIds.filter(id => MALE_ONLY.includes(id)));
  if (rejected.length === 0) return { valid: true, rejectedAddonIds: [], message: "" };
  return {
    valid: false,
    rejectedAddonIds: rejected,
    message:
      g === "male"
        ? "Women's Hormonal Health add-on is not applicable for male profiles."
        : "Men's Performance Pack add-on is not applicable for female profiles.",
  };
}
